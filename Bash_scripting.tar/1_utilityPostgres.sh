# !/bin/bash
# Programa para realizar algunas operaciones utilitarias de Postgres

echo "Prueba bash"

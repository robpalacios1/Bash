# !/bin/bash
# programa para declarar variables, inicializarlas e imprimir valores
# Author: Roberto Palacios

option=$1
result=$2

echo "-----\nReto1\n-----"
echo "la variable option esta inicializada en: $option"
echo "la variable result esta inicializada en: $result"
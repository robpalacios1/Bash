# !/bin/bash
#Programa para revisar declaracion de variables

echo "opcion nombre pasada del script anterior: $nombre"

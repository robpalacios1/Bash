#!/bin/bash
#Download from apache wget

echo "Descargar informacion de internet"
wget -c https://dlcdn.apache.org/tomcat/tomcat-9/v9.0.75/bin/apache-tomcat-9.0.75-windows-x64.zip

# !/bin/bash
# 26_gzip.sh
# Author: Roberto Palacios

echo "zip all scripts from Bash_scripting folder"
tar -cvf Bash_scripting.tar *.sh

# When you zip with gzip the zip done previously it's be remove
gzip Bash_scripting.tar

# Zip only one file with a ratio 9
gzip -9 9_options.sh
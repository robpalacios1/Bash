# !/bin/bash
# 25_tar.sh
# Author: Roberto Palacios

echo "zip all scripts from Bash_scripting folder"
tar -cvf Bash_scripting.tar *.sh